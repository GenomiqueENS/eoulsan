.. _pairtobed:

###############
*pairtobed*
###############
